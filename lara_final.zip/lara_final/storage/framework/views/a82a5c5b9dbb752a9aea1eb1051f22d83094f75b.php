<?php $__env->startSection('content'); ?>
          <div class="container">
            <div class="row justify-content-center">
                <div class="col-sm-11">
                    <div class="card">
                        <div class="card-header">
                            <h1><?php echo e(__('Product Category')); ?></h1>
                        </div>

                        <div class="card-body">
                            <?php if(Session::has('success')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php endif; ?>
                            
                            <form method="post" action="<?php echo e(url('/product/category')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="category" class="col-md-4 col-form-label"><?php echo e(__('Product Category')); ?></label>

                                    <div class="col-md-6">
                                        <input id="category" type="text" class="form-control<?php echo e($errors->has('category') ? ' is-invalid' : ''); ?>" name="category" value="<?php echo e(old('category')); ?>" required autofocus>

                                        <?php if($errors->has('category')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('category')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
          </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>