<?php if(auth()->guard()->check()): ?>
<nav class="col-md-2 d-none d-md-block bg-light sidebar">
      <div class="sidebar-sticky">
        <ul class="nav flex-column accordion" id="dashboard">
              <li class="nav-item">
                <a class="nav-link active" href="#">
                  <span data-feather="home"></span>
                  Dashboard <span class="sr-only">(current)</span>
                </a>
              </li>
              <li class="nav-item" data-toggle="collapse" data-target="#product">
                <a class="nav-link" href="#" role="button">
                  <span data-feather="shopping-cart"></span>
                  Products
                </a>
                <div id="product" class="list-group collapse show" data-parent="#dashboard">
                  <a class="list-group-item list-group-item-action" href="<?php echo e(url('product/category')); ?>">Category</a>
                  <a class="list-group-item list-group-item-action" href="<?php echo e(url('product/sub-category')); ?>">Sub Category</a>
                  <a class="list-group-item list-group-item-action" href="<?php echo e(url('product/product-add')); ?>">Add Product</a>
                  <a class="list-group-item list-group-item-action" href="#">Delete</a>
                </div>
              </li>
              <li class="nav-item" data-toggle="collapse" data-target="#order">
                <a class="nav-link" href="#" role="button">
                  <span data-feather="file"></span>
                  Orders
                </a>
                <div id="order" class="list-group collapse" data-parent="#dashboard">
                  <a class="list-group-item list-group-item-action" href="#">Action</a>
                  <a class="list-group-item list-group-item-action" href="#">Another action</a>
                  <a class="list-group-item list-group-item-action" href="#">Something else here</a>
                  <a class="list-group-item list-group-item-action" href="#">Separated link</a>
                </div>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="users"></span>
                  Customers
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="bar-chart-2"></span>
                  Reports
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <span data-feather="layers"></span>
                  Integrations
                </a>
              </li>
            </ul>

           </div>
        </nav>
<?php endif; ?>