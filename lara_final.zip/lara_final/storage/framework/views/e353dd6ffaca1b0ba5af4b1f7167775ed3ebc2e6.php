<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    You are logged in!
                    <h1><?php echo e(__('Product Category')); ?></h1>
                    <form method="post" action="<?php echo e(url('/product/category')); ?>">
                        <div class="form-group">
                            <label for="category" class="col-md-4 col-form-label"><?php echo e(__('Product Category')); ?></label>

                            <div class="col-md-6">
                                <input id="category" type="text" class="form-control<?php echo e($errors->has('category') ? ' is-invalid' : ''); ?>" name="category" value="<?php echo e(old('category')); ?>" required autofocus>

                                <?php if($errors->has('category')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('category')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>