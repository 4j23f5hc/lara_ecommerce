<?php $__env->startSection('content'); ?>
          <div class="container">
            <div class="row justify-content-center">
                
				<div class="col-sm-11">
					<div class="card bg-gray mb-3">
					  <div class="card-header h4">All Products</div>
					  <?php if(Session::has('success') || Session::has('p_error') ): ?>
						<div class="alert <?php echo e(Session::has('p_error')?'alert-danger' : 'alert-success'); ?>" role="alert">
							<?php echo e(session('success')); ?><?php echo e(session('p_error')); ?>

						</div>
					  <?php endif; ?>
					  <div class="card-body">
						<table class="table table-striped">
						  <thead>
							<tr>
							  <th scope="col">Sl</th>
							  <th scope="col">Name</th>
							  <th scope="col">Image</th>
							  <th scope="col">Price</th>
							  <th scope="col">Action</th>
							</tr>
						  </thead>
						  <tbody>
						  <?php if(count($product) >0): ?>
							<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
							  <th scope="row"><?php echo e($loop->iteration); ?></th>
							  <td><?php echo e($data->name); ?></td>
							  <td><img src="<?php echo e(asset($data->image)); ?>" alt="<?php echo e($data->name); ?>" height="70"></td>
							  <td><?php echo e($data->price); ?></td>
							  <td>
							  
								<a id="view" role="button" class="btn btn-primary btn-sm" title="Product View"  data-toggle="popover" data-title="Product View" data-placement="left" data-html="true"  data-trigger="hover" data-content="
								<b>Name:</b> <?php echo e($data->name); ?><br>
								<b>Price:</b> <?php echo e($data->price); ?><br>
								<b>Description:</b> <?php echo e($data->description); ?><br>
								<b>Image:</b> <br> <img src='<?php echo e(asset($data->image)); ?>' alt='<?php echo e($data->name); ?>' height='200'> <br>
								
								">
								  <span data-feather="eye"></span>
								</a>
							  
								<a Id="edit" role="button" class="btn btn-warning btn-sm" title="Product Edit" data-toggle="modal" data-target="#productInfo_<?php echo e($data->id); ?>">
								  <span data-feather="edit"></span>
								</a>
							  
								<a role="button" class="btn btn-danger btn-sm" title="Product Delete"
                                       onclick="if(!confirm('do you want to delete this <?php echo e($data->name); ?> Product ?')){event.preventDefault(); location.reload();}else{document.getElementById('product-delete-form_<?php echo e($data->id); ?>').submit();} ">
								  <span data-feather="trash-2"></span>
								</a>
								<form id="product-delete-form_<?php echo e($data->id); ?>" action="<?php echo e(url('product/delete')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
										<input type="hidden" name="id" value="<?php echo e($data->id); ?>">
                                 </form>
								
								
								<?php echo $__env->make('product.productInfo', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
							  </td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						  <?php else: ?>
							<tr class="text-center">
							  <td colspan="5" scope="row">
								Their Have No Product at Yet..
							  </td>
							</tr>
						  <?php endif; ?>
						  </tbody>
						</table>
					  </div>
					</div>
				</div>
			</div>
          </div>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

<script>
$(document).ready(function () {
  $('[data-toggle="popover"]').popover();
})
</script>
<?php $__env->stopSection(); ?>







<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>