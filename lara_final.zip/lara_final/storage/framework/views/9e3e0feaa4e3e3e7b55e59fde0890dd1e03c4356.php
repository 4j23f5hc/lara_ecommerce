<?php $__env->startSection('content'); ?>
          <div class="container">
            <div class="row justify-content-center">
                <div class="col-sm-11">
                    <div class="card">
                        <div class="card-header">
                            <h1><?php echo e(__('Product Sub-Category')); ?></h1>
                        </div>

                        <div class="card-body">
                            <?php if(Session::has('success')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php endif; ?>
                            <form method="post" action="<?php echo e(url('product/sub-category')); ?>">
                                <?php echo csrf_field(); ?>
								<div class="form-group">
									<label for="baseCategory">Base Category</label>
									<select name="base" class="form-control <?php echo e($errors->has('base') ? ' is-invalid' : ''); ?>" id="baseCategory">
									  <option value="">Please Select Base Category</option>
									  <?php $__currentLoopData = $base; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($data->id); ?>"><?php echo e(title_case($data->name)); ?></option>
									  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
									<?php if($errors->has('base')): ?>
										<span class="invalid-feedback" role="alert">
											<strong><?php echo e($errors->first('base')); ?></strong>
										</span>
									<?php endif; ?>
								</div>
                                <div class="form-group">
                                    <label for="sub_category"><?php echo e(__('Product Sub-Category')); ?></label>
									<input id="sub_category" type="text" class="form-control<?php echo e($errors->has('sub_category') ? ' is-invalid' : ''); ?>" name="sub_category" value="<?php echo e(old('sub_category')); ?>" required autofocus>

									<?php if($errors->has('sub_category')): ?>
										<span class="invalid-feedback" role="alert">
											<strong><?php echo e($errors->first('sub_category')); ?></strong>
										</span>
									<?php endif; ?>
                                </div>
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>
				
				<div class="col-sm-11">
					<div class="card text-white bg-dark mb-3">
					  <div class="card-header h3">Main & Sub Category</div>
					  <div class="card-body">
						<table class="table table-striped">
						  <thead>
							<tr>
							  <th scope="col">Sl</th>
							  <th scope="col">Category Name</th>
							  <th scope="col">Sub Category</th>
							</tr>
						  </thead>
						  <tbody>
						  <?php if(count($base) >0): ?>
							<?php $__currentLoopData = $base; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
							  <th class="align-middle" scope="row"><?php echo e($loop->iteration); ?></th>
							  <td class="align-middle h1"><?php echo e($data->name); ?></td>
							  <td>
								<table class="table table-dark mb-0">
									<?php $__currentLoopData = $data->subCateg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcateg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr class="bg-dark">
										<td><?php echo e($subcateg->name); ?></td>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</table>
							  </td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						  <?php else: ?>
							<tr class="text-center">
							  <td colspan="3" scope="row">
								Their Have No Main Category at Yet..
							  </td>
							</tr>
						  <?php endif; ?>
						  </tbody>
						</table>
					  </div>
					</div>
				</div>
			
			</div>
          </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>