<!-- Product Info Modal -->
<div class="modal fade actionModal" id="productInfo_<?php echo e($data->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="productEditForm" method="post" action="<?php echo e(url('product/product-edit')); ?>" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
			<input type="hidden" name="id" value="<?php echo e($data->id); ?>">
			
			<div class="form-group">
				<label for="name"><?php echo e(__('Product Name')); ?></label>
				<input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')? old('name') : $data->name); ?>" required autofocus>

				<?php if($errors->has('name')): ?>
					<span class="invalid-feedback" role="alert">
						<strong><?php echo e($errors->first('name')); ?></strong>
					</span>
				<?php endif; ?>
			</div>
			
			<div class="form-group">
				<label for="price"><?php echo e(__('Product Price')); ?></label>
				<input id="price" type="text" class="form-control<?php echo e($errors->has('price') ? ' is-invalid' : ''); ?>" name="price" value="<?php echo e(old('price')?old('price'): $data->price); ?>" required>

				<?php if($errors->has('price')): ?>
					<span class="invalid-feedback" role="alert">
						<strong><?php echo e($errors->first('price')); ?></strong>
					</span>
				<?php endif; ?>
			</div>
			
			<div class="form-group">
				<label for="description"><?php echo e(__('Product Description')); ?></label>
				<textarea id="description" type="text" class="form-control <?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="description" rows="4"><?php echo e(old('description')? old('description') : $data->description); ?></textarea>

				<?php if($errors->has('description')): ?>
					<span class="invalid-feedback" role="alert">
						<strong><?php echo e($errors->first('description')); ?></strong>
					</span>
				<?php endif; ?>
			</div>
			
			<div class="form-group">
				<img src="<?php echo e(asset($data->image)); ?>" alt="<?php echo e($data->name); ?>" height="200"><br>
				<label for="image"><?php echo e(__('Product Image')); ?></label>
				<input type="file" name="image" class="form-control-file <?php echo e($errors->has('image') ? ' is-invalid' : ''); ?>" id="image" value="<?php echo e(old('image')); ?>">
				<?php if($errors->has('image')): ?>
					<span class="invalid-feedback" role="alert">
						<strong><?php echo e($errors->first('image')); ?></strong>
					</span>
				<?php endif; ?>
			</div>
			<button id="productEditButton" type="submit" class="btn btn-primary">Submit</button>
		</form>
                        
      </div>
    </div>
  </div>
</div>