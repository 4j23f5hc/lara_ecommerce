<?php $__env->startSection('content'); ?>
          <div class="container">
            <div class="row justify-content-center">
                
				<div class="col-sm-11">
					<div class="card bg-gray mb-3">
					  <div class="card-header h4">All Products</div>
					  <div class="card-body">
						<table class="table table-striped">
						  <thead>
							<tr>
							  <th scope="col">Sl</th>
							  <th scope="col">Name</th>
							  <th scope="col">Image</th>
							  <th scope="col">Price</th>
							  <th scope="col">Action</th>
							</tr>
						  </thead>
						  <tbody>
						  <?php if(count($product) >0): ?>
							<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
							  <th scope="row"><?php echo e($loop->iteration); ?></th>
							  <td><?php echo e($data->name); ?></td>
							  <td><img src="<?php echo e(asset($data->image)); ?>" alt="<?php echo e($data->name); ?>" height="70"></td>
							  <td><?php echo e($data->price); ?></td>
							  <td>
							  
								<a id="view" role="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#productInfo_<?php echo e($data->id); ?>">
								  <span data-feather="eye"></span>
								</a>
							  
								<a Id="edit" role="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#productInfo_<?php echo e($data->id); ?>">
								  <span data-feather="edit"></span>
								</a>
							  
								<a role="button" class="btn btn-danger btn-sm">
								  <span data-feather="trash-2"></span>
								</a>
							  </td>
							</tr>
								
								<?php echo $__env->make('product.productInfo', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						  <?php else: ?>
							<tr class="text-center">
							  <td colspan="5" scope="row">
								Their Have No Product at Yet..
							  </td>
							</tr>
						  <?php endif; ?>
						  </tbody>
						</table>
					  </div>
					</div>
				</div>
			</div>
          </div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
	$('#view').click(function(){
		
		$('.modal-title').html('View Product');
		$('#productEditForm').attr('action','');
		$('#productEditButton').hide();
	});
	
})
</script>
<?php $__env->stopSection(); ?>







<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>