<?php $__env->startComponent('mail::message'); ?>

Hello Sir,

<?php echo e($data->msg); ?>



Thanks,<br>
<?php echo e($data->name); ?><br>
<?php echo e($data->email); ?><br>
<?php echo e($data->phone); ?><br>
<?php echo $__env->renderComponent(); ?>
